# Cloudify Chef Plugin

* Master Branch [![Build Status](https://travis-ci.org/cloudify-cosmo/cloudify-chef-plugin.svg?branch=master)](https://travis-ci.org/cloudify-cosmo/cloudify-chef-plugin)

Cloudify plugin for [Chef](https://www.getchef.com/chef/).

## Usage

See [Chef Plugin](http://getcloudify.org/guide/3.1/plugin-chef.html)
