cosmo-plugin-chef-client-common
===============================
