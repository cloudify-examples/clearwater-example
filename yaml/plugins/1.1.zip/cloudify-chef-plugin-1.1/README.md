# Cloudify Chef Plugin

Cloudify plugin for [Chef](https://www.getchef.com/chef/).

## Usage

See [Chef Plugin](http://getcloudify.org/guide/3.1/plugin-chef.html)
