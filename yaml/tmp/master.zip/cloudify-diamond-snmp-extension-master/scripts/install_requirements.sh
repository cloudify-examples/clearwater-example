#!/bin/bash

pip install pysnmp

